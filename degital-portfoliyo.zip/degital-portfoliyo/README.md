# Degital portfoliyo

A Pen created on CodePen.

Original URL: [https://codepen.io/qlezxxfs-the-typescripter/pen/gbaQxEK](https://codepen.io/qlezxxfs-the-typescripter/pen/gbaQxEK).


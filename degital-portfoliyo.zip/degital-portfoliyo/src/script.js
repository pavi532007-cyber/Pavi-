// Add name dynamically
document.getElementById("name").textContent = "My Name is N. Pavithra";